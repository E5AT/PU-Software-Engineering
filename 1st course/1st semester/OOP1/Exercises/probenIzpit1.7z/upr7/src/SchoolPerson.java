import java.util.LinkedList;

public class SchoolPerson {
    LinkedList<Person> persons = new LinkedList<Person>();

    void addPerson(Person p) {
        persons.add(p);
    }

    Student findBestGirlStudent() {
        Student best = null;
        for (Person p : persons) {
            if (p instanceof Student)
                if (((Student) p).gender == 'ж')
                    if (best == null || (((Student) p).averageGrade > best.averageGrade))
                        best = (Student) p;
        }
        return best;
    }

    double calculateAverageSalaryOfTeacher() {
        double sum = 0;
        int count = 0;
        for (Person p : persons)
            if (p instanceof Teacher) {
                sum += ((Teacher) p).salary;
                count++;
            }
        return sum / count;
    }
}
