function loadImages() {
    for (let i = 1; i <= 12; i++) {
        let e = document.createElement("div");
        
        e.id = "img-" + i;
        e.classList.add("image");

        e.style.gridArea = "img" + i;
        e.style.backgroundImage = "url('Images/" + i + ".png')"

        e.addEventListener("click", function() { showImg(i) });

        document.getElementById("images-container").appendChild(e);
    }
}

function showImg(img) {
    console.log(img);
    document.getElementById("selected-image").style.backgroundImage = "url('Images/" + img + ".png')";
    document.getElementById("background-image").style.backgroundImage = "url('Images/" + img + ".png')";  
}