// OnClick Функция
function alertFunction() {
    alert("Hello");

    console.log(sum(1, 2));

    changeDiv();
    changeStyleByClass();
    createNewElement();
    getValueFromInput();
}

function printInConsole() {
    console.log(sum(1, 2));
}


// Променливи
var a;
let b;
const c = 4;

// Функция
function sum(a, b) {
    return a + b;
}

//Стрелкова функция
let sum2 = (a, b) => a + b;

// Промяна на стил по id
function changeStyleById() {
    document.getElementById("my-div").innerHTML = "My div";

    let div = document.getElementById("my-div");

    div.style.display = "inline";
    div.style.width = "100px";
    div.style.height = "30px";
    div.style.backgroundColor = "#ddd";

    div.classList.add("class-name"); //.remove() за премахване на клас
}

//Промяна на стил по class
function changeStyleByClass() {
    let elements = document.querySelectorAll(".list-item"); //!

    for (let i = 0; i < elements.length; i++) { //!
        elements[i].style.backgroundColor = "pink";
    }
}

// Взимане на стойност
function getValueFromInput() {
    let value = document.getElementById("input").value;

    alert("Value: " + value);
}

//Създаване на елемент
function createNewElement() {
    let newButton = document.createElement("button");
    
    newButton.id = "newButton";
    newButton.classList.add("btn-class");

    newButton.innerHTML = "Натисни ме";

    newButton.addEventListener("click", function() {
        alert("Бутонът беше натиснат!");
    });

    document.body.appendChild(newButton);
}