let count = 1, orderPrice = 0;

function addProduct() {
    let name = document.getElementById("product-name-input").value;
    let price = parseFloat(document.getElementById("product-price-input").value).toFixed(2);
    let quantity = parseInt(document.getElementById("product-quantity-input").value);

    if (name != "" && price >= 0 && quantity >= 0) {
        let tr = document.createElement("tr");
        tr.id = "tr-" + count;
        document.getElementById("products-table").appendChild(tr);

        let nameTd = document.createElement("td");
        let priceTd = document.createElement("td");
        let quantityTd = document.createElement("td");
        let totalPriceTd = document.createElement("td");

        nameTd.innerText = name;
        priceTd.innerText = price  + " лв";
        quantityTd.innerText = quantity;
        totalPriceTd.innerText = (price * quantity) + " лв";

        tr.appendChild(nameTd);
        tr.appendChild(priceTd);
        tr.appendChild(quantityTd);
        tr.appendChild(totalPriceTd);

        document.getElementById("product-name-input").value = "";
        document.getElementById("product-price-input").value = "";
        document.getElementById("product-quantity-input").value = "";

        orderPrice += price * quantity;

        count++;
    } else {
        alert("Грешни стойности!");
    }

    document.getElementById("order-price").innerText = "Общо: " + orderPrice + " лв";
}
