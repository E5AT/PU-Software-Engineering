#include <iostream>
using namespace std;
// а)
void setNotDiv3(long a[], int L) {
  if (a)
    for (long i{ }, val{ 1 }; i < L; ++i, val += val % 3)
      a[i] = val;
}
// начало на в)
void printArray(const long a[], int L) {
  if (!a || L < 1) return;
  cout << "  Масив в обратен ред:\n";
  for (int i = L - 1; i >= 0; --i) {
    cout << a[i];
    if (i) cout << " , ";
  }
  cout << endl;
}
// начало на г)
void printOdd(const long a[], int L) {
  if (!a || L < 1) return;
  cout << "  Нечетни елементи на масив:\n";
  for (int i{ }; i < L; ++i)
    if (a[i] % 2) cout << a[i] << "  ";
  cout << "\n  (край на нечетните елементи)\n";
}
// начало на д)
int countEven(const long a[], int L) {
  if (!a) return 0;
  int cn{ };
  for (int i{ }; i < L; ++i)
    if (a[i] % 2 == 0) ++cn;
  return cn;
}
int main() {
  // system("chcp 1251 > nul");
  // б)
  const int Len{ 15 };
  long ar[Len];
  setNotDiv3(ar, Len);
  // завършек на в)
  printArray(ar, Len);
  // завършек на г)
  printOdd(ar, Len);
  // завършек на д)
  cout << "  Брой на четните елементи: "
    << countEven(ar, Len) << "\n\n\n";
}