#include <iostream>
using namespace std;
#include <iomanip>
#include <ctime>
int main() {
  // system("chcp 1251 > nul");
  // а)
  const int Len{ 16 }, width{ 4 };
  int ar1[Len], ar2[Len];
  for (int i{ }; i < Len; ++i) {
    ar1[i] = rand() % 21 * 2 - 15;
    ar2[i] = rand() % 21 * 2 - 15;
    cout << setw(width) << i; // начало на б)
  }
  // завършек на б)
  cout << endl;
  for (int elm : ar1) cout << setw(width) << elm;
  cout << endl;
  for (int elm : ar2) cout << setw(width) << elm;
  cout << endl;
  // в)
  cout << "Двойки равни елементи с равни индекси от двата масива:\n";
  for (int i{ }; i < Len; ++i)
    if (ar1[i] == ar2[i])
      cout << "  индекс " << i << " ; стойност " << ar1[i] << endl;
  cout << "  (край на двойките)\n";
  // г)
  cout << "Делители от 1-я масив и съответни делими от 2-я масив:\n";
  cout << "  (с възможни повторения)\n";
  for (int elm1 : ar1)
    if (elm1) {
      bool isFirst{ true };
      for (int elm2 : ar2)
        if (elm2 % elm1 == 0) {
          if (isFirst) {
            cout << elm1 << " ->  ";
            isFirst = false;
          }
          cout << elm2 << " ";
        }
      if (!isFirst) cout << endl;
    }
  cout << "Делители от 1-я масив и съответни делими от 2-я масив:\n";
  cout << "  (БЕЗ повторения)\n";
  for (int i1{ 0 }; i1 < Len; ++i1)
    if (ar1[i1]) {
      int f{ };
      while (ar1[f] != ar1[i1]) ++f;
      if (f < i1) continue;
      bool isFirst{ true };
      for (int i2{ }; i2 < Len; ++i2) {
        f = 0;
        while (ar2[f] != ar2[i2]) ++f;
        if (f < i2) continue;
        if (ar2[i2] % ar1[i1] == 0) {
          if (isFirst) {
            cout << ar1[i1] << " ->  ";
            isFirst = false;
          }
          cout << ar2[i2] << " ";
        }
      }
      if (!isFirst) cout << endl;
    }
}