#include <iostream>
using namespace std;
// начало на а)
void readArraty(long a[], int L, long min, long max) {
  if (!a || L < 1) return;
  if (min > max) swap(min, max);
  cout << "Въведете масив от " << L << " цели числа от "
    << min << " до " << max << ":\n";
  for (int i{ }; i < L; i += min <= a[i] && a[i] <= max) {
    cout << "  за индекс " << i << ": ";
    cin >> a[i];
  }
}
// начало на б)
void writeMaxPairSum(const long a[], int L) {
  if (!a || L < 2) return;
  long max{ a[0] + a[1] };
  for (int i{ 2 }; i < L; ++i)
    if (max < a[i - 1] + a[i]) max = a[i - 1] + a[i];
  cout << "Максимална сума на два съседни елемента: " << max << endl;
}
// начало на в)
void writeEqualsEvenOdd(const long a[], int L) {
  if (!a || L < 2) return;
  cout << "Двойки съседни елементи с еднаква четност:\n";
  for (int i{ 0 }; i < L - 1; ++i)
    if (a[i] % 2 == 0 == (a[i + 1] % 2 == 0))
      cout << "  индекси: " << i << " , " << i + 1
      << "; стойности: " << a[i] << " , " << a[i + 1] << endl;
  cout << "  (край на двойките)\n";
}
// начало на г)
void writePairsInSymmetricPlaces(const long a[], int Len) {
  if (!a || Len < 2) return;
  cout << "Двойки симетрични елементи с различна четност:\n";
  for (int L{ 0 }, R{ Len - 1 }; L < R; ++L, --R)
    if (a[L] % 2 == 0 != (a[R] % 2 == 0))
      cout << "  " << a[L] << " , " << a[R] << endl;
  cout << "  (край на двойките)\n\n";
}

int main() {
  // system("chcp 1251 > nul");
  // завършек на а)
  const int Len{ 9 };
  const long minVal{ -10 }, maxVal{ 20 };
  long ar[Len];
  readArraty(ar, Len, minVal, maxVal);
  // завършек на б)
  writeMaxPairSum(ar, Len);
  // завършек на в)
  writeEqualsEvenOdd(ar, Len);
  // завършек на г)
  writePairsInSymmetricPlaces(ar, Len);
}