#include <iostream>
using namespace std;
#include <ctime>
// начало на а)
void setRandomOdd(long a[], int L, long leftBound, long rightBound) {
  if (!a) return;
  if (leftBound % 2 == 0) ++leftBound;
  if (rightBound % 2 == 0) --rightBound;
  if (leftBound > rightBound) swap(leftBound, rightBound);
  for (int i{ }; i < L; ++i)
    a[i] = rand() % ((rightBound - leftBound) / 2 + 1) * 2 + leftBound;
}
// начало на б)
void showArray(long const a[], int L) {
  if (!a || L < 1) return;
  cout << "Масив: ";
  for (int i{ }; i < L; ++i) cout << "  " << a[i];
  cout << endl;
}
// начало на в)
void showAfterMax(long const a[], int L) {
  if (!a || L < 1) return;
  int iMax{ L - 1 };
  long max{ a[iMax] };
  for (int i{ L - 2 }; i >= 0; --i)
    if (max < a[i]) max = a[i], iMax = i;
  cout << "Брой на елементите след последния максимален: "
    << L - 1 - iMax << endl;
  if (iMax < L - 1) {
    cout << "  Стойности на тези елементи: ";
    while (++iMax < L) cout << " " << a[iMax];
    cout << endl;
  }
}
// начало на г)
void showDifferentValues(long const a[], int L) {
  if (a && L > 0) {
    cout << "Различни стойности на елементи: ";
    for (int pos{ 0 }; pos < L; ++pos) {
      int i{ 0 };
      while (i < pos && a[i] != a[pos]) ++i;
      if (i == pos) cout << " " << a[pos];
    }
    cout << "\n";
  }
}
int main() {
  system("chcp 1251 > nul");
  // завършек на а)
  srand((unsigned)time(nullptr));
  const int Len{ 15 };
  long ar[Len];
  setRandomOdd(ar, Len, -11, 25);
  // завършек на б)
  showArray(ar, Len);
  // завършек на в)
  showAfterMax(ar, Len);
  // завършек на г)
  showDifferentValues(ar, Len);
}
