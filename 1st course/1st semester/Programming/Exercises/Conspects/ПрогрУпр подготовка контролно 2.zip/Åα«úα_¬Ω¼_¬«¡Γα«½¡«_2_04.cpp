#include <iostream>
using namespace std;
#include <ctime>
// а)
void setRandom(long a[], int L, long leftBound, long rightBound) {
  if (!a) return;
  if (leftBound > rightBound) swap(leftBound, rightBound);
  for (int i{ }; i < L; ++i)
    a[i] = rand() % (rightBound - leftBound + 1) + leftBound;
}
// начало на в)
void showArray(long const a[], int L) {
  if (!a || L < 1) return;
  cout << "Масив: ";
  for (int i{ }; i < L; ++i) cout << "  " << a[i];
  cout << endl;
}
// начало на г)
void showIndexes(const long a[], int L, long number) {
  if (!a || L < 1) return;
  cout << "Индекси на елементи със стойност " << number << ": ";
  for (int i{ }; i < L; ++i)
    if (a[i] == number) cout << " " << i;
  cout << " (край на индексите)\n";

}
// начало на д)
void showFirstLastIndexOver(const long a[], int L, long num) {
  if (!a) return;
  int first{ };
  while (first < L && a[first] <= num) ++first;
  if (first == L)
    cout << "В масива няма елемент, по-голям от " << num << ".\n";
  else {
    int Last{ L - 1 };
    while (a[Last] <= num) --Last;
    cout << "Елемент, по-голям от " << num
      << ":\n  първи: индекс " << first
      << ", стойност " << a[first]
      << "\n  последен: индекс " << Last
      << ", стойност " << a[Last] << endl;
  }
}
// начало на е)
void showBeginSequence(const long a[], int L, long n) {
  if (!a) return;
  cout << "Най-дългo начало от елементи, под " << n << ": ";
  for (int i{ }; i<L; ++i)
    if (a[i] >= n) break;
    else cout << " " << a[i];
  cout << " (край на елементите)\n";
}

int main() {
  // system("chcp 1251 > nul");
  // б)
  srand((unsigned)time(nullptr));
  const int Len{ 10 };
  long ar[Len];
  setRandom(ar, Len, -6, 11);
  // завършек на в)
  showArray(ar, Len);
  // завършек на г)
  long num;
  cout << "Въведете търсено число: ";
  cin >> num;
  showIndexes(ar, Len, num);
  // завършек на д)
  showFirstLastIndexOver(ar, Len, num);
  // завършек на е)
  showBeginSequence(ar, Len, num);
}
