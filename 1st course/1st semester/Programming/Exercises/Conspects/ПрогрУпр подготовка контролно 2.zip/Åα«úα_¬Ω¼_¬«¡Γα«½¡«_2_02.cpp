#include <iostream>
using namespace std;
// а)
void readArray(double a[], int L, double minVal, double maxVal) {
  if (!a || L < 0) return;
  if (minVal > maxVal) swap(minVal, maxVal);
  cout << "Въведете масив от " << L << " числа:\n";
  for (int i{ }; i < L; i += minVal <= a[i] && a[i] <= maxVal) {
    cout << "   число от " << minVal << " до " << maxVal
      << " за индекс " << i << ": ";
    cin >> a[i];
  }
}
// начало на в)
void writeArray(const double a[], int L) {
  if (a && L > 0) {
    cout << "Mасив:\n";
    for (int i{ }; i < L; ++i) cout << "  " << a[i];
    cout << endl;
  }
}
// начало на г)
double maxElm(const double a[], int L) {
  if (!a || L < 1) return NAN;
  double max{ *a };
  for (int i{ 1 }; i < L; ++i) if (max < a[i]) max = a[i];
  return max;
}
// начало на д)
void writeIndexesMax(double const a[], int L) {
  if (a && L > 0) {
    double max = maxElm(a, L);
    cout << "Индекси на максимални елементи: ";
    for (int i{ }; i < L; ++i)
      if (a[i] == max) cout << " " << i;
    cout << "  (край на индексите)\n";
  }
}
// начало на e)
double minAndCount(const double a[], int L, int& count) {
  if (!a || L < 0) { count = 0; return NAN; }
  double min{ a[0] };
  count = 1;
  for (int i{ 1 }; i < L; ++i)
    if (min == a[i]) ++count;
    else if (min > a[i]) min = a[i], count = 1;
  return min;
}
// начало на ж)
double sumOddElms(double const a[], int L) {
  if (!a) return NAN;
  double sum{ };
  for (int i{ }; i < L; ++i) if (a[i] < 0) sum += a[i];
  return sum;
}
int main() {
  // system("chcp 1251 > nul");
  double const minBound{ -100.5 }, maxBound{ 45.5 };
  // б)
  int const Len{ 7 };
  double nums[Len];
  readArray(nums, Len, 45.5, -100.5);
  // завършек на в)
  writeArray(nums, Len);
  // завършек на г)
  cout << "Максимлана стойност на елемент: "
    << maxElm(nums, Len) << endl;
  // завършек на д)
  writeIndexesMax(nums, Len);
  // завършек на е)
  int countMin;
  double min = minAndCount(nums, Len, countMin);
  cout << "Минимум: " << min
    << "\nБрой на минималните елементи: " << countMin << endl;
  // завършек на ж)
  cout << "Сума на отрицателните елеметни: "
    << sumOddElms(nums, Len) << "\n\n\n";
}