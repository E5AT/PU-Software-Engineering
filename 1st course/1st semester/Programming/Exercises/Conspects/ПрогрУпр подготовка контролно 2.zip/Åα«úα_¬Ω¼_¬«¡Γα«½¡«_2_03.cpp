#include <iostream>
using namespace std;
#include <ctime>
// а)
void setRandom(long a[], int L, long leftBound, long rightBound) {
  if (!a) return;
  if (leftBound > rightBound) swap(leftBound, rightBound);
  for (int i{ }; i < L; ++i)
    a[i] = rand() % (rightBound - leftBound + 1) + leftBound;
}
// начало на в)
void showArray(long const a[], int L) {
  if (!a || L < 1) return;
  cout << "Масив: ";
  for (int i{ }; i < L; ++i) cout << "  " << a[i];
  cout << endl;
}
// начало на г)
double averageOddElms(const long a[], int L, int& countOdd) {
  if (!a || L < 1) {
    countOdd = -1;
    return NAN;
  }
  // или throw invalid_argument("(няма масив)"); // вместо горния if
  long sumOdd{ };
  countOdd = 0;
  for (int i{ }; i < L; ++i)
    if (a[i] % 2) ++countOdd, sumOdd += a[i];
  return sumOdd / (double)countOdd;
  // при 0==countOdd ще бъде върната стойност NAN
}
// начало на д)
void showFirstLastDiv5(const long a[], int L) {
  if (!a || L < 0) return;
  int first{ };
  while (first < L && a[first] % 5) ++first;
  if (first == L) cout << "В масива няма елемент, кратен на 5.\n";
  else {
    int Last{ L - 1 };
    while (a[Last] % 5) --Last;
    cout << "Елемент, кратен на 5:\n  първи: индекс "
      << first << ", стойнсот " << a[first]
      << "\n  последен: индекс "
      << Last << ", стойност " << a[Last] << endl;
  }
}
// начало на е)
void showLastSequenceOdd(const long a[], int L) {
  if (!a) return;
  int Last{ L };
  while (Last > 0 && a[Last - 1] % 2) --Last;
  cout << "Най-дълга редица от последни нечетни елементи: ";
  while (Last < L) cout << " " << a[Last++];
  cout << "  (край)\n";
}
// начало на ж
void newValueSub5(long a[], int L) {
  if (!a) return;
  long oldValue;
  for (int i{ }; i < L; ++i)
    // if (long oldValue = a[i]; oldValue < -5)
      // Ифът от горния ред е възможен от C++17 вместо следващия if.
      // Настройката може да бъде зададена във Visual Studio чрез:
      // Project -> ... Properties -> General
      // -> C++ Language Standard -> ISO C++17 Standard (/std:c++17)
      // При наличие на горния if (т. е. при активиран C++17)
      // декларацията "long oldValue;" преди цикъла става излишна.
    if ((oldValue = a[i]) < -5) // за C++14
      do {
        cout << "  За индекс " << i << " и предишна стойност " << oldValue
          << " въведете стойност над " << oldValue << ": ";
        cin >> a[i];
      } while (a[i] <= oldValue);
}

int main() {
  // system("chcp 1251 > nul");
  // б)
  srand((unsigned)time(nullptr));
  const long lowerBound{ -10 }, upperBound{ 15 };
  const int Len{ 10 };
  long ar[Len];
  setRandom(ar, Len, lowerBound, upperBound);
  // завършек на в)
  showArray(ar, Len);
  // завършек на г)
  int countOdd{ };
  double average = averageOddElms(ar, Len, countOdd);
  if (countOdd < 1) cout << "Няма нечетни елементи.\n";
  else
    cout << "Средно аритметично на нечетните елементи: "
    << average << endl;
  // завършек на д)
  showFirstLastDiv5(ar, Len);
  // завършек на е)
  showLastSequenceOdd(ar, Len);
  // завършек на ж)
  newValueSub5(ar, Len);
  // з)
  showArray(ar, Len);
}