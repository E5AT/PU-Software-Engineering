#include <iostream>
using namespace std;
int main() {
  //system("chcp 1251 > nul");
  cout << "----- signed int -----\n"
    << "брой байтове: " << sizeof(signed int) << endl
    << "уникално име: " << typeid(signed int).name() << endl;
  cout << "----- int -----\n"
    << "брой байтове: " << sizeof(int) << endl
    << "уникално име: " << typeid(int).name() << endl;
  cout << "----- unsigned int -----\n"
    << "брой байтове: " << sizeof(unsigned int) << endl
    << "уникално име: " << typeid(unsigned int).name() << endl;
  cout << "----- unsigned -----\n"
    << "брой байтове: " << sizeof(unsigned) << endl
    << "уникално име: " << typeid(unsigned).name() << endl;
  cout << "----- long -----\n"
    << "брой байтове: " << sizeof(long) << endl
    << "уникално име: " << typeid(long).name() << endl;
  cout << "----- long long -----\n"
    << "брой байтове: " << sizeof(long long) << endl
    << "уникално име: " << typeid(long long).name() << endl;
  cout << "----- double -----\n"
    << "брой байтове: " << sizeof(double) << endl
    << "уникално име: " << typeid(double).name() << endl;
  cout << "----- long double -----\n"
    << "брой байтове: " << sizeof(long double) << endl
    << "уникално име: " << typeid(long double).name() << endl;

  cout << endl << boolalpha
    << "is_fundamental_v<short> -> " << is_fundamental_v<short> << endl
    << "is_fundamental_v<long double> -> " << is_fundamental_v<long double> << endl
    << "is_fundamental_v<string> -> " << is_fundamental_v<string> << endl
    << "is_fundamental_v<short&> -> " << is_fundamental_v<short&> << endl;
}