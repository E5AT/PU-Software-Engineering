#include <iostream>
using namespace std;
int main() {
  //system("chcp 1251 > nul");
  cout << "Текст, изпратен към cout." << endl;
  cerr << "Текст, изпратен към cerr." << endl;
  clog << "Текст, изпратен към clog." << endl;
  double d1, d2, d3;
  cout << "Въведете число: ";
  cin >> d1;
  cout << "d -> " << d1 << endl;
  cout << "Въведете две числа: ";
  cin >> d2 >> d3;
  cout << d2 << " / " << d3 << " -> " << d2 / d3 << endl;
}