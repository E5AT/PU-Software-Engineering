#include <iostream>
using namespace std;
#include <format>
int main() {
  //system("chcp 1251 > nul");
  string s{ format("{0:=>2}{0:*>3}{0:#>4}","z") };
  cout << '"' << s << "\"\n";
  s = format("{0}{1:10.4f}{0}", '|', 123.12);
  // 10.5 означава в 10 позиции с 5 знака за дробната част
  cout << s << endl;
  s = format("{0}{1:<10.4f}{0}", '|', 123.12);
  cout << s << endl;
  cout << format("{0}{1:>10.4f}{0}", '|', 123.12) << endl
       << format("{0}{1:<10.4f}{0}", '|', 123.12) << endl;
}