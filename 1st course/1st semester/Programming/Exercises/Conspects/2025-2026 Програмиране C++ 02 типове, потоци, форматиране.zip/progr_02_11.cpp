#include <iostream>
using namespace std;
int main() {
  //system("chcp 1251 > nul");
  string str;
  cout << "Въведете низ без бели полета: ";
  cin >> str;
  string line = string(2 + str.length(), '=');
  cout << line << "\n\"" << str << "\"\n" << line << endl;
}