#include <iostream>
using namespace std;
#include <fstream>
int main() {
  //system("chcp 1251 > nul");
  string fileName{ "file.txt"s };
  ofstream fOut(fileName, ios::out);
  if (!fOut) {
    cout << "Неуспешен опит за създаване на файл " << fileName << ".\n";
    abort();
  }
  fOut << 120 << "   " << -2.45 << "     ";
  fOut.close();
  ifstream fIn(fileName, ios::in);
  if (!fIn) {
    cout << "Неуспешен опит за отваряне на файл " << fileName << ".\n";
    abort();
  }
  double d;
  while (true) {
    fIn >> d;
    if (!fIn) break;
    cout << d << endl;
  }
  fIn.close();
}