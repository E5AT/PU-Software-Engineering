#include <iostream>
using namespace std;
int main() {
  //system("chcp 1251 > nul");
  int x, y, z;
  cout << "Въведете три цели числа: ";
  cin >> x >> y >> z;
  cout << x << " + " << y << " + " << z
    << " = " << x + y + z << endl;
}