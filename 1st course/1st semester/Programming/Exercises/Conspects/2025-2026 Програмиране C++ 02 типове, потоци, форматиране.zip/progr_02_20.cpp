#include <iostream>
using namespace std;
#include <sstream>
int main() {
  //system("chcp 1251 > nul");
  ostringstream strOut;
  strOut << 120 << "   " << -2.45;
  cout << '"' << strOut.str() << "\"\n";
  string s{ strOut.str() };
  istringstream strIn{ s };
  int i;
  strIn >> i;
  cout << i << endl;
  double d;
  strIn >> d;
  cout << d << endl;
}