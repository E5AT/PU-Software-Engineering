#include <iostream>
using namespace std;
int main() {
  //system("chcp 1251 > nul");
  char x, y, z;
  cout << "Въведете три знака от тип char: ";
  cin >> x >> y >> z;
  cout << "най-голям знак: '" << max(x, max(y, z)) << "'\n";
  cout << "най-малък знак: '" << min(x, min(y, z)) << "'\n";
}