#include <iostream>
using namespace std;
#include <iomanip>
int main() {
  //system("chcp 1251 > nul");
  short g = +32768; // това може,
  // но +32768 е извън обхвата на short
  // и съдържанието на паметта се интерпретира
  // като код на числото -32768 (което е в обхвата на short)
  cout << "g -> " << g << endl; // тук g има стойност -32768
  short h{ 32767 }; // това може, защото е в обхвата на short
  cout << "h -> " << h << endl;
  // не може short j{ 32768 }; // литералът е над максимума за short
  string s{ "12"s + "34"s }; // литералите са от тип string
  // плюсът е конкатенация на низовете
  cout << '|' << setw(6) << s << "|\n"
    << left << '|' << setw(6) << s << "|\n"
    << right << '|' << setw(6) << s << "|\n"
    << left << '|' << setw(6) << s << "|\n"
    // тук все още е валидно left
    << '|' << setw(6) << s << "|\n";
  cout << string(8, '=') << "\n\n";
  double d{ 12345.6789012345 };
  cout << d << endl
    << fixed << d << endl
    // тук все още е валидно fixed
    << d << endl
    << scientific << d << endl
    << defaultfloat << d << "\n\n";
  d = 1e20;
  cout << d << endl // тук все още е валидно defaultfloat
    << fixed << d << endl
    << scientific << d << endl
    // тук все още е валидно scientific
    << d << endl
    << defaultfloat << d << "\n\n";
}