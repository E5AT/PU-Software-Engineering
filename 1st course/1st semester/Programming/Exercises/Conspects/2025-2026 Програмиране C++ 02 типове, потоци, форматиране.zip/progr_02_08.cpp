#include <iostream>
using namespace std;
int main() {
  //system("chcp 1251 > nul");
  bool x, y, z;
  cout << "Въведете три булеви стойности като true или false: ";
  cin >> boolalpha >> x >> y >> z;
  // първи начин
  cout << boolalpha
    << "( " << x << " or " << y << " ) and " << z
    << " or " << x << " and " << y << " and not " << z
    << " = " << ((x || y) && z || x && y && !z) << endl;
  // втори начин
  cout << boolalpha
    << "( " << x << " or " << y << " ) and " << z
    << " or " << x << " and " << y << " and not " << z
    << " = " << ((x or y) and z or x and y and !z) << endl;
}