#include <iostream>
using namespace std;
#include <iomanip>
int main() {
  //system("chcp 1251 > nul");
  string s1, s2;
  cout << "Въведете два низа без бели полета: ";
  cin >> s1 >> s2;
  s1 = "\""s + s1 + "\""s;
  s2 = "\""s + s2 + "\""s;
  size_t width{ max(s1.length(),s2.length()) };
  cout << setw(width) << s1 << endl << setw(width) << s2 << endl;
}