#include <iostream>
using namespace std;
int main() {
  //system("chcp 1251 > nul");
  auto n{ -123LL }; // n е от тип long long
                    // защото -123LL е от тип long long
  cout << "----- n -----  "
    << "брой байтове: " << sizeof(n)
    << " ; уникално име: " << typeid(n).name() << endl
    << "----- long long -----  "
    << "брой байтове: " << sizeof(long long)
    << " ; уникално име: " << typeid(long long).name() << endl;

  typedef long double T1; // Т1 е ново име на типа long double
  T1 n1{ -12.3L }; // литералът -12.3L е от тип long double
  cout << "----- T1 -----  "
    << "брой байтове: " << sizeof(T1)
    << " ; уникално име: " << typeid(T1).name() << endl
    << "----- n1 -----  "
    << "брой байтове: " << sizeof(n1)
    << " ; уникално име: " << typeid(n1).name() << endl
    << "----- long double -----  "
    << "брой байтове: " << sizeof(long double)
    << " ; уникално име: " << typeid(long double).name() << endl;

  decltype(2 * 6) n2{ 345 }; // 2 * 6 има стойност от тип int
                             // и затова n2 е от тип int
  typedef decltype(1 + 1 + 1) T2; // T2 е ново име на типа int
  cout << "----- T2 -----  "
    << "брой байтове: " << sizeof(T2)
    << " ; уникално име: " << typeid(T2).name() << endl
    << "----- n2 -----  "
    << "брой байтове: " << sizeof(n2)
    << " ; уникално име: " << typeid(n2).name() << endl
    << "----- int -----  "
    << "брой байтове: " << sizeof(int)
    << " ; уникално име: " << typeid(int).name() << endl;
  using TU = T2; // TU е ново име на типа T2
  cout << "----- TU -----  "
    << "брой байтове: " << sizeof(TU)
    << " ; уникално име: " << typeid(TU).name() << endl;
}