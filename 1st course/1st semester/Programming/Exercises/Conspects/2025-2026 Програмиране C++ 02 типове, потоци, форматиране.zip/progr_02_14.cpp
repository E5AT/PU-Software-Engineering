#include <iostream>
using namespace std;
int main() {
  //system("chcp 1251 > nul");
  cout << "  d:\n";
  const double d{ -123.4 };
  cout << "d -> " << d << endl;
  const_cast<double&>(d) = 9999.1;
  cout << "d -> " << d << endl;
  cout << "d -> " << const_cast<double&>(d) << endl;
  cout << "  r:\n";
  constexpr double r{ -123.4 };
  cout << "r -> " << r << endl;
  const_cast<double&>(r) = 9999.1;
  cout << "r -> " << r << endl;
  cout << "r -> " << const_cast<double&>(r) << endl;
}