#include <iostream>
using namespace std;
int main() {
  //system("chcp 1251 > nul");
  bool b = true;
  cout << "b -> " << b << endl
    << boolalpha << "b -> " << b << endl;
  cout << "Въведете булева стойност като 1 или 0: ";
  cin >> b;
  cout << noboolalpha << "b -> " << b << endl
    << boolalpha << "b -> " << b << endl;
  cout << "Въведете булева стойност като true или false: ";
  cin >> boolalpha >> b;
  cout << noboolalpha << "b -> " << b << endl
    << boolalpha << "b -> " << b << endl;
}