#include <iostream>
using namespace std;
int main() {
  //system("chcp 1251 > nul");
  char x, y, z;
  cout << "Въведете три знака от тип char: ";
  cin >> x >> y >> z;
  cout << '\'' << z << "'  '" << y << "'  '" << x << "'" << endl;
  cout << string(2, x) << endl
    << string(4, y) << endl
    << string(6, z) << endl;
}